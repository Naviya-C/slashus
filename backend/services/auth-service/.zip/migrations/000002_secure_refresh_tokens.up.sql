-- Refresh token rotation + reuse detection.
--
-- Adds the family concept: one login starts a family, every rotation stays in
-- it, and presenting an already-used token revokes the whole family.

ALTER TABLE refresh_tokens
    ADD COLUMN family_id UUID,
    ADD COLUMN rotated_at TIMESTAMPTZ;

-- Existing rows predate families. Give each its own so they behave sanely.
UPDATE refresh_tokens SET family_id = gen_random_uuid() WHERE family_id IS NULL;

ALTER TABLE refresh_tokens ALTER COLUMN family_id SET NOT NULL;

-- Lookup is always by hash, so it must be indexed. UNIQUE also turns a
-- double-insert into a loud database error rather than a silent ambiguity
-- about which row is authoritative.
CREATE UNIQUE INDEX idx_refresh_tokens_hash ON refresh_tokens(token_hash);

-- Family revocation runs on every logout and every reuse detection.
CREATE INDEX idx_refresh_tokens_family ON refresh_tokens(family_id);

-- Supports scheduled cleanup of expired rows.
CREATE INDEX idx_refresh_tokens_expires ON refresh_tokens(expires_at);

-- ONE-TIME: tokens issued before this migration were stored in PLAINTEXT.
-- They cannot be converted (you cannot re-hash what the client holds), and
-- leaving them means plaintext credentials stay in the table. Revoke them;
-- affected users log in once more.
UPDATE refresh_tokens SET revoked = TRUE WHERE rotated_at IS NULL;
