"""Configuration: validation, and the .env loading regression."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from agentic_service.config.settings import DatabaseSettings, Settings


def test_blocking_driver_is_upgraded_to_async():
    """psycopg2 used from an async endpoint blocks the event loop for the
    duration of every query."""
    assert DatabaseSettings(url="postgresql://u:p@h/db").url.startswith("postgresql+asyncpg://")


def test_unsupported_driver_is_rejected():
    with pytest.raises(ValidationError):
        DatabaseSettings(url="mysql://u:p@h/db")


def test_production_requires_redis(monkeypatch):
    """Without it the checkpointer (working memory), the long-term store and
    the semantic cache are all per-process."""
    monkeypatch.setenv("ENVIRONMENT", "production")
    monkeypatch.setenv("LLM_API_KEY", "k")
    monkeypatch.setenv("SECURITY_GATEWAY_SHARED_SECRET", "s")
    monkeypatch.delenv("REDIS_URL", raising=False)
    with pytest.raises(ValidationError, match="REDIS_URL"):
        Settings()


def test_production_requires_a_gateway_secret(monkeypatch):
    monkeypatch.setenv("ENVIRONMENT", "production")
    monkeypatch.setenv("LLM_API_KEY", "k")
    monkeypatch.setenv("REDIS_URL", "redis://localhost")
    monkeypatch.delenv("SECURITY_GATEWAY_SHARED_SECRET", raising=False)
    with pytest.raises(ValidationError, match="GATEWAY_SHARED_SECRET"):
        Settings()


def test_retry_budget_is_bounded():
    """One retry layer. Nested retries multiply."""
    assert Settings().llm.max_retries <= 5


def test_nested_settings_read_the_dotenv_file(tmp_path, monkeypatch):
    """Regression.

    Nested settings groups are built via ``default_factory``, and
    pydantic-settings resolves each group's sources from ITS OWN
    ``model_config`` -- it does not inherit the parent's. With ``env_file`` set
    only on the top-level ``Settings``, every nested group silently ignored
    ``.env`` and startup failed with 'Field required' for DATABASE_URL.
    """
    (tmp_path / ".env").write_text(
        "ENVIRONMENT=local\n"
        "DATABASE_URL=postgresql://u:p@from-dotenv/db\n"
        "LLM_API_KEY=from-dotenv\n"
        "REDIS_URL=redis://from-dotenv:6379/0\n"
        "EMBEDDING_GRPC_URL=from-dotenv:50051\n"
        "AGENT_MAX_TOOL_CALLS=9\n"
        "CACHE_SIMILARITY_THRESHOLD=0.91\n"
    )
    monkeypatch.chdir(tmp_path)
    for var in ("DATABASE_URL", "LLM_API_KEY", "REDIS_URL", "EMBEDDING_GRPC_URL"):
        monkeypatch.delenv(var, raising=False)

    s = Settings()
    assert "from-dotenv" in s.database.url
    assert s.llm.api_key.get_secret_value() == "from-dotenv"
    assert s.redis.url == "redis://from-dotenv:6379/0"
    assert s.vector.grpc_url == "from-dotenv:50051"
    # every nested group, not just the first
    assert s.agent.max_tool_calls == 9
    assert s.cache.similarity_threshold == 0.91


def test_real_environment_variables_win_over_dotenv(tmp_path, monkeypatch):
    (tmp_path / ".env").write_text("EMBEDDING_GRPC_URL=from-dotenv:50051\n")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("EMBEDDING_GRPC_URL", "from-env:50051")
    assert Settings().vector.grpc_url == "from-env:50051"
