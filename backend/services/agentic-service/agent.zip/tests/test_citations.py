from __future__ import annotations

import json

from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

from agentic_service.agent.runner import TurnRunner


def result(citation, chunk):
    return json.dumps(
        {
            "status": "ok",
            "passages": [
                {
                    "citation": citation,
                    "chunk_id": chunk,
                    "doc_id": "d1",
                    "lesson_title": "Lesson",
                    "page": 2,
                    "source": "book.pdf",
                    "content": "text",
                }
            ],
        }
    )


def test_citations_are_unique_across_search_calls_and_structured():
    state = {
        "messages": [
            HumanMessage(content="question"),
            ToolMessage(
                content=result("C-AAAAAAAAAA", "c1"), name="search_documents", tool_call_id="1"
            ),
            ToolMessage(
                content=result("C-BBBBBBBBBB", "c2"), name="search_documents", tool_call_id="2"
            ),
            AIMessage(content="First [C-AAAAAAAAAA], second [C-BBBBBBBBBB]."),
        ]
    }
    turn = TurnRunner._summarise(state)
    assert {item["citation"] for item in turn.citations} == {"C-AAAAAAAAAA", "C-BBBBBBBBBB"}


def test_invented_citations_are_removed_from_reply_metadata():
    state = {
        "messages": [
            HumanMessage(content="question"),
            ToolMessage(
                content=result("C-AAAAAAAAAA", "c1"), name="search_documents", tool_call_id="1"
            ),
            AIMessage(content="Invented [C-CCCCCCCCCC]."),
        ]
    }
    turn = TurnRunner._summarise(state)
    assert "C-CCCCCCCCCC" not in turn.reply
    assert turn.citations == []
