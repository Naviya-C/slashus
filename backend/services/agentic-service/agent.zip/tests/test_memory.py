from __future__ import annotations

import pytest

from agentic_service.memory.manager import MemoryManager
from agentic_service.memory.repository import InMemoryMemoryRepository
from agentic_service.memory.types import EpisodicMemory, ProceduralMemory, SemanticMemory


class FakeVectors:
    async def embed(self, texts, purpose="query"):
        return [[1.0, 0.0] for _ in texts]


@pytest.fixture
def manager():
    return MemoryManager(InMemoryMemoryRepository(), vectors=FakeVectors(), llm=None)


async def test_semantic_facts_round_trip(manager):
    await manager.remember_fact(
        "u1", SemanticMemory(content="Sitting O/L history", category="goal")
    )
    context = await manager.recall("u1", "history")
    assert any("O/L history" in item.text for item in context.semantic)


async def test_duplicate_semantic_fact_is_upserted(manager):
    memory = SemanticMemory(content="Prefers Sinhala explanations", category="preference")
    first = await manager.remember_fact("u1", memory)
    second = await manager.remember_fact("u1", memory)
    assert first == second
    assert len((await manager.recall("u1", "Sinhala")).semantic) == 1


async def test_episodes_are_recalled_as_exemplars(manager):
    await manager.record_episode(
        "u1",
        EpisodicMemory(
            situation="Asked about the water cycle",
            action="Used a staged breakdown",
            outcome="It clicked",
            lesson="Stage things",
            success=True,
        ),
    )
    text = (await manager.recall("u1", "water cycle")).episodic[0].text
    assert "Situation:" in text and "WORKED" in text


async def test_similar_rules_supersede(manager):
    first = await manager.upsert_rule(
        "u1", ProceduralMemory(instruction="Use everyday Sri Lankan examples first")
    )
    second = await manager.upsert_rule(
        "u1", ProceduralMemory(instruction="Use everyday Sri Lankan examples first please")
    )
    rules = await manager.active_rules("u1")
    assert first == second
    assert len(rules) == 1 and rules[0].version == 2


async def test_memory_never_leaks_between_students(manager):
    await manager.remember_fact("u1", SemanticMemory(content="Secret goal"))
    assert (await manager.recall("u2", "goal")).is_empty()


async def test_erase_is_scoped_by_user_and_kind(manager):
    await manager.remember_fact("u1", SemanticMemory(content="Secret goal"))
    await manager.upsert_rule("u1", ProceduralMemory(instruction="Be concise"))
    assert await manager.erase("u1", "semantic") == 1
    context = await manager.recall("u1", "goal")
    assert not context.semantic and context.procedural
