"""Proof this is a real agent: the MODEL chooses tools, not the code path.

The previous build had a ToolRegistry with descriptions and a catalogue()
method that was never called, no prompt listing tools, and hardcoded string
literals at every call site. These tests fail if that regresses.
"""

from __future__ import annotations

from uuid import UUID

from langchain_core.language_models.fake_chat_models import GenericFakeChatModel
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langgraph.checkpoint.memory import MemorySaver
from langgraph.store.memory import InMemoryStore

from agentic_service.agent.agent import build_agent
from agentic_service.agent.runner import TurnRunner
from agentic_service.agent.tools import build_tools
from agentic_service.config.settings import AgentSettings
from agentic_service.memory.manager import MemoryManager
from agentic_service.memory.repository import InMemoryMemoryRepository

USER = UUID("11111111-1111-1111-1111-111111111111")


class Scripted(GenericFakeChatModel):
    def bind_tools(self, tools, **kw):
        # Record what the model was actually offered.
        self._offered = [t.name for t in tools]
        return self

    def get_num_tokens_from_messages(self, messages, tools=None):
        return len(messages) * 10


class Hit:
    chunk_id = "c1"
    doc_id = "d1"
    source = "science.pdf"
    title = "Water"
    page = 3
    content = "Evaporation, condensation, precipitation."
    score = 1.0


class Outcome:
    failed = False
    user_has_no_documents = False
    hits = [Hit()]  # noqa: RUF012
    filters_applied = []  # noqa: RUF012
    degraded = False


class Titles:
    titles = []  # noqa: RUF012
    total_chunks = 0
    truncated = False
    failed = False


class FakeVectors:
    async def search(self, **kw):
        return Outcome()

    async def list_titles(self, **kw):
        return Titles()

    async def embed(self, texts, purpose="query"):
        return [[1.0, 0.0] for _ in texts]


def make_memory(vectors):
    return MemoryManager(InMemoryMemoryRepository(), vectors=vectors, llm=None)


def make(script):
    store = InMemoryStore()
    vectors = FakeVectors()
    memory = make_memory(vectors)
    model = Scripted(messages=iter(script))
    agent = build_agent(
        model=model,
        tools=build_tools(vectors, memory),
        memory=memory,
        store=store,
        checkpointer=MemorySaver(),
        settings=AgentSettings(),
        base_prompt="You are a tutor.",
    )
    return agent, memory, store


async def test_tools_are_bound_to_the_model():
    """The schemas must reach the model. If nothing is bound, the model cannot
    choose anything and it is not an agent."""
    agent, _, _ = make([AIMessage(content="hi")])
    await agent.ainvoke(
        {"messages": [HumanMessage(content="hello")]},
        {"configurable": {"thread_id": "t", "user_id": str(USER), "doc_ids": []}},
    )
    # build_tools exposes exactly the five student-facing tools
    from agentic_service.agent.tools import build_tools as bt

    vectors = FakeVectors()
    names = {t.name for t in bt(vectors, make_memory(vectors))}
    assert names == {
        "search_documents",
        "list_lessons",
        "remember_about_student",
        "recall_about_student",
        "learn_tutoring_rule",
    }


async def test_model_chosen_tool_is_executed_and_fed_back():
    agent, _, _ = make(
        [
            AIMessage(
                content="",
                tool_calls=[
                    {"name": "search_documents", "args": {"query": "water cycle"}, "id": "1"}
                ],
            ),
            AIMessage(content="Three stages."),
        ]
    )
    out = await agent.ainvoke(
        {"messages": [HumanMessage(content="explain the water cycle")]},
        {"configurable": {"thread_id": "t", "user_id": str(USER), "doc_ids": []}},
    )
    kinds = [m.type for m in out["messages"]]
    assert "tool" in kinds
    assert out["messages"][-1].content == "Three stages."


async def test_the_loop_runs_as_many_iterations_as_the_model_wants():
    """A fixed pipeline has a constant tool count; an agent's is variable."""
    agent, _, _ = make(
        [
            AIMessage(content="", tool_calls=[{"name": "list_lessons", "args": {}, "id": "1"}]),
            AIMessage(
                content="",
                tool_calls=[{"name": "search_documents", "args": {"query": "a"}, "id": "2"}],
            ),
            AIMessage(
                content="",
                tool_calls=[{"name": "search_documents", "args": {"query": "b"}, "id": "3"}],
            ),
            AIMessage(content="Answer."),
        ]
    )
    runner = TurnRunner(
        agent=agent,
        memory=make_memory(FakeVectors()),
        settings=AgentSettings(),
        consolidation_enabled=False,
    )
    result = await runner.run(message="explain the water cycle", user_id=USER, session_id="s1")
    assert result.tool_calls == ["list_lessons", "search_documents", "search_documents"]
    assert result.iterations == 4


async def test_the_model_may_answer_with_no_tools_at_all():
    agent, _, _ = make([AIMessage(content="Hello! What are you studying?")])
    runner = TurnRunner(
        agent=agent,
        memory=make_memory(FakeVectors()),
        settings=AgentSettings(),
        consolidation_enabled=False,
    )
    result = await runner.run(message="hi", user_id=USER, session_id="s1")
    assert result.tool_calls == []
    assert "Hello" in result.reply


async def test_a_tool_call_can_write_memory_the_next_turn_recalls():
    agent, memory, _ = make(
        [
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "remember_about_student",
                        "args": {"content": "Sitting O/L science", "category": "goal"},
                        "id": "1",
                    }
                ],
            ),
            AIMessage(content="Noted."),
        ]
    )
    await agent.ainvoke(
        {"messages": [HumanMessage(content="I'm sitting O/L science")]},
        {"configurable": {"thread_id": "t", "user_id": str(USER), "doc_ids": []}},
    )
    ctx = await memory.recall(str(USER), "exam")
    assert any("O/L science" in m.text for m in ctx.semantic)


async def test_identity_cannot_be_supplied_by_the_model():
    """user_id is not in any tool schema, so an injected instruction inside a
    retrieved chunk has no slot in which to name another student."""
    from agentic_service.agent.tools import build_tools as bt

    vectors = FakeVectors()
    for tool in bt(vectors, make_memory(vectors)):
        fields = set(tool.args_schema.model_fields) if tool.args_schema else set()
        assert "user_id" not in fields, f"{tool.name} exposes user_id to the model"


async def test_stream_emits_the_same_completed_turn_metadata():
    agent, memory, _ = make([AIMessage(content="A grounded answer.")])
    runner = TurnRunner(
        agent=agent, memory=memory, settings=AgentSettings(), consolidation_enabled=False
    )
    events = [
        event
        async for event in runner.stream(
            message="Explain the topic", user_id=USER, session_id="stream-1"
        )
    ]
    assert events[0]["type"] == "turn_started"
    completed = next(event for event in events if event["type"] == "turn_completed")
    assert completed["reply"] == "A grounded answer."
    assert completed["tools_used"] == []


def test_practice_set_id_is_extracted_from_the_tool_result():
    set_id = "22222222-2222-2222-2222-222222222222"
    result = TurnRunner._summarise(
        {
            "messages": [
                HumanMessage(content="Give me an MCQ"),
                AIMessage(
                    content="",
                    tool_calls=[
                        {
                            "name": "save_practice_questions",
                            "args": {"questions": []},
                            "id": "quiz-1",
                        }
                    ],
                ),
                ToolMessage(
                    name="save_practice_questions",
                    tool_call_id="quiz-1",
                    content=(
                        '{"status":"saved","practice_set_id":"'
                        + set_id
                        + '","count":1}'
                    ),
                ),
                AIMessage(content="Your question is ready in the Practice Panel."),
            ]
        }
    )

    assert result.practice_set_id == set_id
