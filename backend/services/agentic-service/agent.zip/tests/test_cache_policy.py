"""Greetings stay live; equivalent substantive questions may be cached.

A cache keyed on similarity alone makes the tutor a robot: "Hi" and
"Hello there" are ~0.95 similar, so it would replay one canned greeting forever.
"""

from __future__ import annotations

import pytest

from agentic_service.cache.policy import (
    CacheDecision,
    classify_request,
    classify_response,
    is_greeting,
)


@pytest.mark.parametrize(
    "msg",
    [
        "Hi",
        "hi!",
        "Hello",
        "Hello there",
        "hey",
        "Good morning",
        "how are you",
        "thanks",
        "Thank you",
        "ok",
        "bye",
        "ආයුබෝවන්",
        "හලෝ",
        "ස්තූතියි",
    ],
)
def test_greetings_are_never_served_from_cache(msg):
    assert classify_request(msg) is not CacheDecision.CACHEABLE


def test_greeting_detection_requires_the_whole_message():
    """'hi' is a greeting; 'hi, explain photosynthesis' is a question that
    happens to open politely."""
    assert is_greeting("hi")
    assert not is_greeting("hi, can you explain photosynthesis to me")


def test_substantive_questions_are_cacheable():
    for msg in [
        "What is the water cycle?",
        "Can you explain the water cycle to me?",
        "ජල චක්‍රය පිළිබඳව පැහැදිලි කරන්න",
    ]:
        assert classify_request(msg) is CacheDecision.CACHEABLE


@pytest.mark.parametrize(
    "msg",
    [
        "explain more",
        "tell me more about that",
        "continue",
        "give me another example",
        "what about the second one",
        "තව විස්තර කරන්න",
        "තවත් උදාහරණයක්",
    ],
)
def test_followups_are_never_cached_mid_conversation(msg):
    """Their answer depends entirely on preceding turns, so two identical
    follow-ups in different conversations need different answers."""
    assert classify_request(msg, has_history=True) is CacheDecision.FOLLOWUP


def test_followup_wording_is_fine_when_there_is_no_history():
    assert (
        classify_request("tell me more about the water cycle stages", has_history=False)
        is CacheDecision.CACHEABLE
    )


def test_even_substantive_turns_with_history_are_not_cached_without_context_fingerprint():
    assert (
        classify_request("Explain the water cycle stages", has_history=True)
        is CacheDecision.HAS_HISTORY
    )


@pytest.mark.parametrize(
    "msg",
    [
        "what did I get wrong last time",
        "what am I studying",
        "do you remember my goal",
        "මගේ ලකුණු මොනවද",
    ],
)
def test_memory_dependent_questions_are_not_cached(msg):
    assert classify_request(msg) is CacheDecision.PERSONAL


def test_very_short_messages_are_not_cached():
    """'the cycle?' and 'the cell?' sit close in embedding space and are not
    the same question."""
    assert classify_request("the cycle?") is CacheDecision.TOO_SHORT


def test_side_effect_turns_are_not_stored():
    """Replaying 'I saved 5 questions' with nothing saved is worse than
    re-running the turn."""
    assert (
        classify_response(answer="Saved 5 questions.", tools_used=["save_practice_questions"])
        is CacheDecision.SIDE_EFFECTS
    )
    assert (
        classify_response(answer="ok", tools_used=["remember_about_student"])
        is CacheDecision.SIDE_EFFECTS
    )


def test_read_only_turns_are_storable():
    assert (
        classify_response(
            answer="The water cycle has three stages.", tools_used=["search_documents"]
        )
        is CacheDecision.CACHEABLE
    )


def test_timeouts_and_empty_answers_are_not_stored():
    assert classify_response(answer="", tools_used=[]) is CacheDecision.EMPTY_ANSWER
    assert (
        classify_response(answer="x", tools_used=[], timed_out=True) is CacheDecision.EMPTY_ANSWER
    )
