from __future__ import annotations

import pytest

from agentic_service.cache.semantic import SemanticCache, cosine, scope_key


class FakeRedis:
    def __init__(self):
        self.h = {}
        self.g = {}

    async def get(self, k):
        return self.g.get(k)

    async def mget(self, *keys):
        return [self.g.get(key) for key in keys]

    async def incr(self, k):
        self.g[k] = str(int(self.g.get(k, 0)) + 1)
        return self.g[k]

    async def hgetall(self, k):
        return self.h.get(k, {})

    async def hset(self, k, f, v):
        self.h.setdefault(k, {})[f] = v

    async def hdel(self, k, f):
        self.h.get(k, {}).pop(f, None)

    async def hlen(self, k):
        return len(self.h.get(k, {}))

    async def expire(self, k, t):
        pass


VOCAB = ["water", "cycle", "explain", "photosynthesis", "what", "is", "the", "stages"]


class FakeVectors:
    async def embed(self, texts, purpose="query"):
        return [[float(t.lower().replace("?", "").split().count(v)) for v in VOCAB] for t in texts]


@pytest.fixture
def cache():
    return SemanticCache(redis=FakeRedis(), vectors=FakeVectors(), threshold=0.9)


def test_cosine_basics():
    assert cosine([1, 0], [1, 0]) == pytest.approx(1.0)
    assert cosine([1, 0], [0, 1]) == pytest.approx(0.0)
    assert cosine([1, 0], [1, 0, 0]) == 0.0  # mismatched dims never crash


async def test_greeting_is_neither_stored_nor_served(cache):
    stored = await cache.store(
        message="Hi", answer="Hello!", user_id="u1", doc_ids=[], tools_used=[], has_history=False
    )
    assert stored is False
    assert (
        await cache.lookup(message="Hello there", user_id="u1", doc_ids=[], has_history=False)
        is None
    )


async def test_equivalent_question_hits(cache):
    await cache.store(
        message="What is the water cycle?",
        answer="Three stages.",
        user_id="u1",
        doc_ids=["d1"],
        tools_used=["search_documents"],
        has_history=False,
    )
    hit = await cache.lookup(
        message="What is the water cycle", user_id="u1", doc_ids=["d1"], has_history=False
    )
    assert hit is not None and hit.answer == "Three stages."


async def test_different_topic_does_not_hit(cache):
    await cache.store(
        message="What is the water cycle?",
        answer="Three stages.",
        user_id="u1",
        doc_ids=["d1"],
        tools_used=[],
        has_history=False,
    )
    assert (
        await cache.lookup(
            message="What is photosynthesis explain",
            user_id="u1",
            doc_ids=["d1"],
            has_history=False,
        )
        is None
    )


async def test_cache_is_isolated_per_user(cache):
    """Answers are grounded in that student's own documents; a shared cache is
    a cross-tenant leak, not an optimisation."""
    await cache.store(
        message="What is the water cycle?",
        answer="Three stages.",
        user_id="u1",
        doc_ids=["d1"],
        tools_used=[],
        has_history=False,
    )
    assert (
        await cache.lookup(
            message="What is the water cycle", user_id="u2", doc_ids=["d1"], has_history=False
        )
        is None
    )


async def test_document_scope_is_part_of_the_key(cache):
    await cache.store(
        message="What is the water cycle?",
        answer="Three stages.",
        user_id="u1",
        doc_ids=["d1"],
        tools_used=[],
        has_history=False,
    )
    assert (
        await cache.lookup(
            message="What is the water cycle", user_id="u1", doc_ids=["d2"], has_history=False
        )
        is None
    )


async def test_new_upload_retires_every_entry(cache):
    await cache.store(
        message="What is the water cycle?",
        answer="Three stages.",
        user_id="u1",
        doc_ids=["d1"],
        tools_used=[],
        has_history=False,
    )
    await cache.invalidate_user("u1")
    assert (
        await cache.lookup(
            message="What is the water cycle", user_id="u1", doc_ids=["d1"], has_history=False
        )
        is None
    )


async def test_memory_update_retires_every_entry(cache):
    await cache.store(
        message="What is the water cycle?",
        answer="Three stages.",
        user_id="u1",
        doc_ids=["d1"],
        tools_used=[],
        has_history=False,
    )
    await cache.invalidate_memory("u1")
    assert (
        await cache.lookup(
            message="What is the water cycle", user_id="u1", doc_ids=["d1"], has_history=False
        )
        is None
    )


async def test_threshold_is_respected():
    strict = SemanticCache(redis=FakeRedis(), vectors=FakeVectors(), threshold=0.999)
    await strict.store(
        message="What is the water cycle stages",
        answer="A",
        user_id="u1",
        doc_ids=[],
        tools_used=[],
        has_history=False,
    )
    assert (
        await strict.lookup(
            message="What is the water cycle", user_id="u1", doc_ids=[], has_history=False
        )
        is None
    )


async def test_disabled_cache_is_a_no_op():
    off = SemanticCache(redis=None, vectors=FakeVectors())
    assert off.enabled is False
    assert (
        await off.lookup(
            message="anything at all here", user_id="u1", doc_ids=[], has_history=False
        )
        is None
    )


async def test_backend_failure_never_fails_the_turn():
    class Broken(FakeRedis):
        async def hgetall(self, k):
            raise RuntimeError("redis down")

    cache = SemanticCache(redis=Broken(), vectors=FakeVectors())
    assert (
        await cache.lookup(
            message="What is the water cycle", user_id="u1", doc_ids=[], has_history=False
        )
        is None
    )


def test_scope_key_separates_users_and_generations():
    assert scope_key("u1", ["d1"], 0, 0) != scope_key("u2", ["d1"], 0, 0)
    assert scope_key("u1", ["d1"], 0, 0) != scope_key("u1", ["d1"], 1, 0)
    assert scope_key("u1", ["d1"], 0, 0) != scope_key("u1", ["d1"], 0, 1)
    assert scope_key("u1", ["d1", "d2"], 0, 0) == scope_key("u1", ["d2", "d1"], 0, 0)
