from pathlib import Path


def test_proto_contract_is_identical_in_both_services():
    agent_root = Path(__file__).resolve().parents[1]
    embedding_proto = agent_root.parent / "embedding-service" / "proto" / "search.proto"
    assert (agent_root / "proto" / "search.proto").read_bytes() == embedding_proto.read_bytes()
