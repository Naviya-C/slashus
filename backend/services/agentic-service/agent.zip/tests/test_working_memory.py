"""Working memory: the bounded window, and the invariants that must not break."""

from __future__ import annotations

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

from agentic_service.memory.working import build_window, repair_boundaries


def test_orphaned_leading_tool_result_is_dropped():
    """A ToolMessage whose AIMessage was trimmed away is a protocol error, not
    a degraded prompt."""
    out = repair_boundaries(
        [ToolMessage(content="r", tool_call_id="1"), HumanMessage(content="hi")]
    )
    assert not isinstance(out[0], ToolMessage)


def test_dangling_tool_call_is_dropped():
    """An AIMessage requesting tools whose results were cut leaves the model
    waiting for answers that never arrive."""
    out = repair_boundaries(
        [
            HumanMessage(content="hi"),
            AIMessage(content="", tool_calls=[{"name": "t", "args": {}, "id": "1"}]),
        ]
    )
    assert not any(getattr(m, "tool_calls", None) for m in out)


def test_paired_tool_exchange_is_preserved():
    msgs = [
        HumanMessage(content="hi"),
        AIMessage(content="", tool_calls=[{"name": "t", "args": {}, "id": "1"}]),
        ToolMessage(content="result", tool_call_id="1"),
        AIMessage(content="done"),
    ]
    assert len(repair_boundaries(msgs)) == 4


def test_window_trims_long_histories():
    def counter(msgs):
        return len(msgs) * 100

    msgs = [HumanMessage(content=f"q{i}") for i in range(50)]
    assert len(build_window(msgs, max_tokens=500, token_counter=counter)) < 50


def test_window_always_leaves_something_to_answer():
    def counter(msgs):
        return len(msgs) * 10_000

    assert build_window([HumanMessage(content="q")], max_tokens=1, token_counter=counter)


def test_system_message_is_prepended_when_supplied():
    def counter(msgs):
        return len(msgs)

    out = build_window(
        [HumanMessage(content="q")],
        max_tokens=100,
        token_counter=counter,
        system=SystemMessage(content="sys"),
    )
    assert isinstance(out[0], SystemMessage)


def test_empty_history_is_safe():
    assert build_window([], max_tokens=100, token_counter=lambda m: 0) == []
