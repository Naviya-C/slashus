from __future__ import annotations

from uuid import UUID

import pytest

from agentic_service.agent.evaluator import AnswerEvaluator

USER = UUID("11111111-1111-1111-1111-111111111111")
QUESTION = UUID("22222222-2222-2222-2222-222222222222")


class Repo:
    def __init__(self, question):
        self.question = question
        self.saved = None

    async def get_question(self, **kwargs):
        return self.question

    async def save_answer(self, **kwargs):
        self.saved = kwargs


class LLM:
    async def ainvoke_json(self, prompt, label="json"):
        return {
            "feedback": "Good structure",
            "rubric_results": [
                {"awarded_marks": 2, "feedback": "covered"},
                {"awarded_marks": 99, "feedback": "clamped"},
            ],
        }


async def test_mcq_marking_is_deterministic():
    repo = Repo(
        {
            "qtype": "mcq",
            "correct_index": 1,
            "options": ["A", "B"],
            "max_marks": 2,
            "explanation": "B is correct",
            "question": "Pick",
        }
    )
    result = await AnswerEvaluator(LLM()).evaluate_and_save(
        repository=repo, user_id=USER, question_id=QUESTION, selected_index=1, answer_text=None
    )
    assert result["marks"] == 2 and result["is_correct"] is True
    assert repo.saved is not None


async def test_mcq_reveals_option_text_not_storage_object():
    repo = Repo(
        {
            "qtype": "mcq",
            "correct_index": 1,
            "options": [
                {"index": 0, "text": "12"},
                {"index": 1, "text": "18"},
            ],
            "max_marks": 1,
            "explanation": "ස්වර 18ක් ඇත.",
            "question": "ස්වර කීයක් තිබේද?",
        }
    )
    result = await AnswerEvaluator(LLM()).evaluate_and_save(
        repository=repo,
        user_id=USER,
        question_id=QUESTION,
        selected_index=0,
        answer_text=None,
    )

    assert result["revealed_answer"] == "18"


async def test_written_marks_are_clamped_to_each_rubric_point():
    repo = Repo(
        {
            "qtype": "structured",
            "question": "Explain",
            "model_answer": "Model",
            "rubric": [{"point": "one", "marks": 2}, {"point": "two", "marks": 3}],
            "max_marks": 5,
        }
    )
    result = await AnswerEvaluator(LLM()).evaluate_and_save(
        repository=repo,
        user_id=USER,
        question_id=QUESTION,
        selected_index=None,
        answer_text="My answer",
    )
    assert result["marks"] == 5
    assert result["rubric_results"][1]["awarded_marks"] == 3


async def test_missing_written_answer_is_rejected():
    repo = Repo({"qtype": "essay", "question": "Explain", "max_marks": 10})
    with pytest.raises(ValueError, match="answer_text"):
        await AnswerEvaluator(LLM()).evaluate_and_save(
            repository=repo, user_id=USER, question_id=QUESTION, selected_index=None, answer_text=""
        )
