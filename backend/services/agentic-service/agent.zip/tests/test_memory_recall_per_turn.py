from __future__ import annotations

from langchain_core.messages import HumanMessage

from agentic_service.agent.agent import MemoryRecallMiddleware
from agentic_service.memory.types import RecalledContext


class SpyMemory:
    def __init__(self):
        self.calls = 0

    async def recall(self, user_id, query):
        self.calls += 1
        return RecalledContext()


class Runtime:
    context = {"user_id": "u1"}  # noqa: RUF012
    config = {"configurable": {"user_id": "u1"}}  # noqa: RUF012


async def test_recall_runs_once_per_user_turn_not_once_per_thread():
    memory = SpyMemory()
    middleware = MemoryRecallMiddleware(memory, "system")
    state = {"messages": [HumanMessage(content="first")], "recalled": None}
    first = await middleware.abefore_model(state, Runtime())
    state.update(first)
    assert memory.calls == 1

    assert await middleware.abefore_model(state, Runtime()) is None
    assert memory.calls == 1

    state["messages"].append(HumanMessage(content="second"))
    second = await middleware.abefore_model(state, Runtime())
    assert second["recalled_turn_id"] != first["recalled_turn_id"]
    assert memory.calls == 2
