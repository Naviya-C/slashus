"""Client and server classes corresponding to protobuf-defined services."""

import grpc
import warnings

from . import search_pb2 as search__pb2

GRPC_GENERATED_VERSION = "1.83.0"
GRPC_VERSION = grpc.__version__
_version_not_supported = False

try:
    from grpc._utilities import first_version_is_lower

    _version_not_supported = first_version_is_lower(GRPC_VERSION, GRPC_GENERATED_VERSION)
except ImportError:
    _version_not_supported = True

if _version_not_supported:
    raise RuntimeError(
        f"The grpc package installed is at version {GRPC_VERSION},"
        + " but the generated code in search_pb2_grpc.py depends on"
        + f" grpcio>={GRPC_GENERATED_VERSION}."
        + f" Please upgrade your grpc module to grpcio>={GRPC_GENERATED_VERSION}"
        + f" or downgrade your generated code using grpcio-tools<={GRPC_VERSION}."
    )


class VectorSearchStub:
    """Missing associated documentation comment in .proto file."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.Search = channel.unary_unary(
            "/slashus.search.v2.VectorSearch/Search",
            request_serializer=search__pb2.SearchRequest.SerializeToString,
            response_deserializer=search__pb2.SearchResponse.FromString,
            _registered_method=True,
        )
        self.ListTitles = channel.unary_unary(
            "/slashus.search.v2.VectorSearch/ListTitles",
            request_serializer=search__pb2.ListTitlesRequest.SerializeToString,
            response_deserializer=search__pb2.ListTitlesResponse.FromString,
            _registered_method=True,
        )
        self.Embed = channel.unary_unary(
            "/slashus.search.v2.VectorSearch/Embed",
            request_serializer=search__pb2.EmbedRequest.SerializeToString,
            response_deserializer=search__pb2.EmbedResponse.FromString,
            _registered_method=True,
        )


class VectorSearchServicer:
    """Missing associated documentation comment in .proto file."""

    def Search(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def ListTitles(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def Embed(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")


def add_VectorSearchServicer_to_server(servicer, server):
    rpc_method_handlers = {
        "Search": grpc.unary_unary_rpc_method_handler(
            servicer.Search,
            request_deserializer=search__pb2.SearchRequest.FromString,
            response_serializer=search__pb2.SearchResponse.SerializeToString,
        ),
        "ListTitles": grpc.unary_unary_rpc_method_handler(
            servicer.ListTitles,
            request_deserializer=search__pb2.ListTitlesRequest.FromString,
            response_serializer=search__pb2.ListTitlesResponse.SerializeToString,
        ),
        "Embed": grpc.unary_unary_rpc_method_handler(
            servicer.Embed,
            request_deserializer=search__pb2.EmbedRequest.FromString,
            response_serializer=search__pb2.EmbedResponse.SerializeToString,
        ),
    }
    generic_handler = grpc.method_handlers_generic_handler(
        "slashus.search.v2.VectorSearch", rpc_method_handlers
    )
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers("slashus.search.v2.VectorSearch", rpc_method_handlers)


# This class is part of an EXPERIMENTAL API.
class VectorSearch:
    """Missing associated documentation comment in .proto file."""

    @staticmethod
    def Search(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/slashus.search.v2.VectorSearch/Search",
            search__pb2.SearchRequest.SerializeToString,
            search__pb2.SearchResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def ListTitles(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/slashus.search.v2.VectorSearch/ListTitles",
            search__pb2.ListTitlesRequest.SerializeToString,
            search__pb2.ListTitlesResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def Embed(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/slashus.search.v2.VectorSearch/Embed",
            search__pb2.EmbedRequest.SerializeToString,
            search__pb2.EmbedResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )
